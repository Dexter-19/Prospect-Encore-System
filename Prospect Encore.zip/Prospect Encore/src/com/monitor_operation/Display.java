/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.monitor_operation;
import com.employee_operations.EmployeeOperations;
import static com.employee_operations.EmployeeOperations.adminModule;
import static com.employee_operations.EmployeeOperations.adminVerify;
import com.prospect_opertion.*;
import static com.prospect_opertion.ProspectOperations.Logout;
import static com.prospect_opertion.ProspectOperations.monitorModule;
import static com.prospect_opertion.ProspectOperations.employeeVerify;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Kartik Gaur
 */
public class Display {
    static Scanner sc=new Scanner(System.in);
    String a=sc.nextLine();
    public static void mainModule() throws SQLException
    {EmployeeOperations.cls();
     System.out.println("Welcome To Prospect Encore Management System:");
     System.out.println("Login");
     System.out.println("Select Module");
     System.out.println("1-Employee");
     System.out.println("2-Admin");
     System.out.println("3-Exit");
     int c=sc.nextInt();
     switch(c)
     {case 1:if(employeeVerify())
             {System.out.println("Logged In Sucessfully");
              monitorModule();
              mainModule();
             }
             else
             {System.out.println("Wrong Input Credentials:");
              mainModule();
             }
             break;
      case 2:if(adminVerify())
             {System.out.println("Logged In Sucessfully");
              adminModule();
              mainModule();
             }
             else
             {System.out.println("Wrong Input Credentials:");
              mainModule();
             }
             break;
      case 3:Logout();
             System.exit(0);
             break;
      default:System.out.println("Wrong Input Selected:");
     }
    }
    
    public static void main(String[] args) throws SQLException
    { 
        mainModule();
    }
    
}
