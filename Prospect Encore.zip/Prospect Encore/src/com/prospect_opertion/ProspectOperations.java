/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prospect_opertion;
import com.employee_operations.EmployeeOperations;
import java.sql.*;
import java.util.*;

/**
 *
 * @author Kartik Gaur
 */
public class ProspectOperations {
    static Connection con=null;
    //static Connection con2=null;
    static Scanner sc=new Scanner(System.in);
    static
    {   try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/prospect","root","");
        //con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/prospect","root","");
        if(con==null)
        {System.out.println("Connection Not Esatblished with the database");
        }
        } catch (Exception e) {
            System.out.println("Connection Not Esatblished with the database:"+e);
        }
    }//Inserting
   /* public void print()
    {System.out.println("Hey");
    }*/
    public static void insertData() throws SQLException
    {System.out.println("Enter Prospect Information:");
     System.out.println("Enter Prospect Name:");
     String name=sc.nextLine();
     System.out.println("Enter Prospect Phone Number:");
     String phone=sc.nextLine();
     System.out.println("Enter Prospect Address:");
     String addr=sc.nextLine();
     System.out.println("Enter Prospect Car Model Choice:");
     String model=sc.nextLine();
     System.out.println("Enter Choosen Cars Color");
     String color=sc.nextLine();
     System.out.println("Select Hotness Level of Prospect");
         System.out.print("1-Hot  ");
         System.out.print("2-Warm  ");
         System.out.println("3-Cool");
         int n=sc.nextInt();
         String hotness=null;
         switch(n)
     {case 1:hotness="Hot";
             break;
      case 2:hotness="Warm";
             break;
      case 3:hotness="Cool";
             break;
      default:System.out.println("Invalid Input Value");
     }
     System.out.println("Enter Prospect Day Of Visit:(MM/DD/YYYY)");
     sc.nextLine();
     String dofvisit=sc.nextLine();
     java.util.Date d=new java.util.Date(dofvisit);
     java.sql.Date d1=new java.sql.Date(d.getYear(),d.getMonth(),d.getDate());
     PreparedStatement stmt=con.prepareStatement(" insert into prospect(pname,pphone,padd,pmodel,pcolor,dofvisit,hotness) values(?,?,?,?,?,?,?)");
     stmt.setString(1, name);
     stmt.setString(2, phone);
     stmt.setString(3,addr);
     stmt.setString(4, model);
     stmt.setString(5, color);
     stmt.setDate(6,d1);
     stmt.setString(7, hotness);
     int i=stmt.executeUpdate();
     if(i!=0)
     {System.out.println("Record Inserted");
     }
     else
     {System.out.println("Record not inserted:");
     }
    }
    //Display all data
    public static void showProspect() throws SQLException
    {Statement stmt=con.createStatement();
     ResultSet rs=stmt.executeQuery("Select *from prospect");
     while(rs.next())
     {System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6)+"  "+rs.getDate(7)+"  "+rs.getString(8));
     } 
    }
    //Updating
    public static void updateData() throws SQLException
    {System.out.println("Which Data You Want to update");
     System.out.println("1-PHONE");
     System.out.println("2-MODEL");
     System.out.println("3-COLOUR");
     System.out.println("4-HOTNESS");
     int n=sc.nextInt();
     switch(n)
     {case 1:phoneUpdateData();
             break;
      case 2:modelUpdateData();
             break;
      case 3:colourUpdateData();
             break;
      case 4:hotnessUpdateData();
             break;
      default:System.out.println("Invalid Input Value");
     }
     
    }
    public static void phoneUpdateData() throws SQLException
    {System.out.println("Enter Prospect Id");
     int id=sc.nextInt();
     PreparedStatement stmt=con.prepareStatement("Select *from prospect where pid=?");
     stmt.setInt(1, id);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {System.out.println("Enter the updated phone number");
         sc.nextLine();
         String p=sc.nextLine();
      stmt=con.prepareStatement("update prospect set pphone=? where pid=?");
      stmt.setString(1,p);
      stmt.setInt(2, id);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Phone no updated");
      }
      else
      {System.out.println("Phone number not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    public static void modelUpdateData() throws SQLException
    {System.out.println("Enter Prospect Id");
     int id=sc.nextInt();
     PreparedStatement stmt=con.prepareStatement("Select *from prospect where pid=?");
     stmt.setInt(1, id);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {   System.out.println("Enter the updated model name of the car:");
         sc.nextLine();
         String m=sc.nextLine();
      stmt=con.prepareStatement("update prospect set pmodel=? where pid=?");
      stmt.setString(1,m);
      stmt.setInt(2,id);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Car Model updated");
      }
      else
      {System.out.println("Car Model not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    public static void colourUpdateData() throws SQLException
    {System.out.println("Enter Prospect Id");
     int id=sc.nextInt();
     PreparedStatement stmt=con.prepareStatement("Select *from prospect where pid=?");
     stmt.setInt(1, id);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {   System.out.println("Enter the updated colour of the car:");
         sc.nextLine();
         String c=sc.nextLine();
      stmt=con.prepareStatement("update prospect set pcolor=? where pid=?");
      stmt.setString(1,c);
      stmt.setInt(2, id);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Car Colour updated");
      }
      else
      {System.out.println("Car Colour not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    public static void hotnessUpdateData() throws SQLException
    {System.out.println("Enter Prospect Id");
     int id=sc.nextInt();
     PreparedStatement stmt=con.prepareStatement("Select *from prospect where pid=?");
     stmt.setInt(1, id);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {   
  
         System.out.println("Select New Hotness Level of Prospect");
         System.out.println("1-Hot");
         System.out.println("2-Warm");
         System.out.println("3-Cool");
         int n=sc.nextInt();
         String h=null;
         switch(n)
     {case 1:h="Hot";
             break;
      case 2:h="Warm";
             break;
      case 3:h="Cool";
             break;
      default:System.out.println("Invalid Input Value");
     }
      stmt=con.prepareStatement("update prospect set hotness=? where pid=?");
      stmt.setString(1,h);
      stmt.setInt(2, id);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("HOtness Level Updated");
      }
      else
      {System.out.println("Hotness Level not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    //Searching
    public static void searchData() throws SQLException
    {System.out.println("Search Prospect Data By:");
     System.out.println("1-Hotness");
     System.out.println("2-Prospect Id");
     int n=sc.nextInt();
     switch(n)
     {case 1:hotnessSearchData();
             break;
      case 2:prospectIdSearchData();
             break;
      default:System.out.println("Invalid Input Value");
     }
    }
    public static void hotnessSearchData() throws SQLException
    {System.out.println("Select Hotness Level of Prospect");
         System.out.println("1-Hot");
         System.out.println("2-Warm");
         System.out.println("3-Cool");
         int n=sc.nextInt();
         String h=null;
         switch(n)
     {case 1:h="Hot";
             break;
      case 2:h="Warm";
             break;
      case 3:h="Cool";
             break;
      default:System.out.println("Invalid Input Value");
     }
     PreparedStatement stmt=con.prepareStatement("Select *from prospect where hotness=?");
     stmt.setString(1, h);
     ResultSet rs=stmt.executeQuery();
     while(rs.next())
     {System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5)+""+rs.getString(6)+""+rs.getDate(7)+""+rs.getString(8));
     }   
    }
    public static void prospectIdSearchData() throws SQLException
    {System.out.println("Select Prospect ID you Want to search");
     int p=sc.nextInt();
     PreparedStatement stmt=con.prepareStatement("Select *from prospect where pid=?");
     stmt.setInt(1, p);
     ResultSet rs=stmt.executeQuery();
     while(rs.next())
     {System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5)+""+rs.getString(6)+""+rs.getDate(7)+""+rs.getString(8));
     }   
    }
    //Change password
    public static void changeEmpPass() throws SQLException
    {System.out.println("Enter Your Username");
     String u=sc.nextLine();
     System.out.println("Enter Your Current Password");
     String p=sc.nextLine();
     PreparedStatement stmt=con.prepareStatement("Select *from employee where uname=? and upass=?");
     stmt.setString(1, u);
     stmt.setString(2, p);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {   System.out.println("Enter the new password:");
         String m=sc.nextLine();
      stmt=con.prepareStatement("update employee set upass=? where uname=?");
      stmt.setString(1,m);
      stmt.setString(2, u);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Password Updated updated");
      }
      else
      {System.out.println("Password not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    //Logout
    public static void Logout() throws SQLException
    {
     con.close();
     //con2.close();
     System.out.println("Logged out");
    }
    //Homepage Module
    
    //Login Verify
    public static boolean employeeVerify() throws SQLException
    {System.out.println("Enter Your Username");
     //sc.nextLine();
     String u=sc.nextLine();
     System.out.println("Enter Your Current Password");
     String p=sc.nextLine();
     PreparedStatement stmt=con.prepareStatement("Select *from employee where uname=? and upass=? and status=?");
     stmt.setString(1, u);
     stmt.setString(2, p);
     stmt.setBoolean(3, true);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {return true;
     }
     return false;
    }
    //Employee Module
    public static void monitorModule() throws SQLException
    {EmployeeOperations.cls();
     System.out.println("Welcome To Employee Module");
     System.out.println("Select the operation you want to perform:");
     System.out.println("1-Add New Prospect");
     System.out.println("2-View All Prospects");
     System.out.println("3-Update Prospects");
     System.out.println("4-Search");
     System.out.println("5-Change own Password:");
     System.out.println("6-Signout");
     int em=sc.nextInt();
     switch(em)
     {case 1: insertData();
              monitorModule();
             break;
      case 2: showProspect();
              monitorModule();
             break;
      case 3: updateData();
              monitorModule();
             break;
      case 4:searchData();
             monitorModule();
             break;
      case 5:changeEmpPass();
             monitorModule();
             break;
      case 6:System.out.println("Employee Signed Out Sucessfully:");
             break;
      default:System.out.println("Wrong Input:");
     }
    }
    
}