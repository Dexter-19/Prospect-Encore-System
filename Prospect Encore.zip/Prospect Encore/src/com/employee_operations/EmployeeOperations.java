/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.employee_operations;
import static com.prospect_opertion.ProspectOperations.searchData;
import static com.prospect_opertion.ProspectOperations.showProspect;
import java.sql.*;
import java.util.*;

/**
 *
 * @author Kartik Gaur
 */
public class EmployeeOperations {
    static Connection con=null;
    //static Connection con2=null;
    static Scanner sc=new Scanner(System.in);
    static
    {   try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/prospect","root","");
        //con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/prospect","root","");
        if(con==null)
        {System.out.println("Connection Not Esatblished with the database");
        }
        } catch (Exception e) {
            System.out.println("Connection Not Esatblished with the database:"+e);
        }
    }
    public static void insertEmpData() throws SQLException
    {System.out.println("Create Account:");
         System.out.print("1-Admin  ");
         System.out.println("2-Monitor ");
         int n=sc.nextInt();
         String acc=null;
         switch(n)
     {case 1:acc="Admin";
             break;
      case 2:acc="Monitor";
             break;
      default:System.out.println("Invalid Input Value");
     }
     System.out.println("Enter "+acc + " Information:");
     System.out.println("Enter Username:");
     sc.nextLine();
     String uname=sc.nextLine();
     System.out.println("Password");
     String upass=sc.nextLine();
     System.out.println("Enter Full Name");
     String fname=sc.nextLine();
     System.out.println("Enter Phone No.");
     String phone=sc.nextLine();
     System.out.println("Enter Email");
     String email=sc.nextLine();
     System.out.println("Enter Status");
         System.out.print("1-Active  ");
         System.out.println("2-In-Active ");
         int m=sc.nextInt();
         boolean status=true;
         switch(n)
     {case 1:status=true;
             break;
      case 2:status=false;
             break;
      default:System.out.println("Invalid Input Value");
     }
     PreparedStatement stmt=con.prepareStatement(" insert into employee values(?,?,?,?,?,?,?)");
     stmt.setString(1, uname);
     stmt.setString(2, upass);
     stmt.setString(3,acc);
     stmt.setString(4, fname);
     stmt.setString(5, phone);
     stmt.setString(6,email);
     stmt.setBoolean(7, status);
     int i=stmt.executeUpdate();
     if(i!=0)
     {System.out.println("Record Inserted");
     }
     else
     {System.out.println("Record not inserted:");
     }
    }
    //Display Employee Data
    public static void showEmpData() throws SQLException
    {Statement stmt=con.createStatement();
     ResultSet rs=stmt.executeQuery("Select *from employee");
     while(rs.next())
     {System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6)+"  "+rs.getBoolean(7));
     } 
    }
    //changing password
    public static void changePassword() throws SQLException
    {System.out.println("Change Password");
         System.out.print("1-Self  ");
         System.out.println("2-Others ");
         int n=sc.nextInt();
         switch(n)
     {case 1:changeSelfPassword();
             break;
      case 2:changeOthersPassword();
             break;
      default:System.out.println("Invalid Input Value");
     }
    }
    public static void changeSelfPassword() throws SQLException
    {System.out.println("Enter Your Username");
     sc.nextLine();
     String u=sc.nextLine();
     System.out.println("Enter Your Current Password");
     String p=sc.nextLine();
     PreparedStatement stmt=con.prepareStatement("Select *from employee where uname=? and upass=?");
     stmt.setString(1, u);
     stmt.setString(2, p);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {   System.out.println("Enter the new password:");
         String m=sc.nextLine();
      stmt=con.prepareStatement("update employee set upass=? where uname=?");
      stmt.setString(1,m);
      stmt.setString(2, u);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Password of Self Updated");
      }
      else
      {System.out.println("Password not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    public static void changeOthersPassword() throws SQLException
    {System.out.println("Enter Your Other Employees Username");
     sc.nextLine();
     String u=sc.nextLine();
     System.out.println("Enter Your Other Employees Current Password");
     String p=sc.nextLine();
     PreparedStatement stmt=con.prepareStatement("Select *from employee where uname=? and upass=?");
     stmt.setString(1, u);
     stmt.setString(2, p);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {   System.out.println("Enter the other employees new password:");
         String m=sc.nextLine();
      stmt=con.prepareStatement("update employee set upass=? where uname=?");
      stmt.setString(1,m);
      stmt.setString(2, u);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Password of "+u+ " Updated ");
      }
      else
      {System.out.println("Password not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    public static  void statusUpdate() throws SQLException
    {System.out.println("Enter Username of Employee Whoose Account Status Is To Be Updated");
     sc.nextLine();
     String u=sc.nextLine();
     PreparedStatement stmt=con.prepareStatement("Select *from employee where uname=?");
     stmt.setString(1, u);
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {  System.out.println("Enter Current Status");
         System.out.print("1-Activated  ");
         System.out.println("2-Deactivated ");
         int m=sc.nextInt();
         boolean status=true;
         switch(m)
     {case 1:status=true;
             break;
      case 2:status=false;
             break;
      default:System.out.println("Invalid Input Value");
     }
      stmt=con.prepareStatement("update employee set status=? where uname=?");
      stmt.setBoolean(1,status);
      stmt.setString(2, u);
      int i=stmt.executeUpdate();
      if(i!=0)
      {System.out.println("Status Updated Sucessfully");
      }
      else
      {System.out.println("Status not updated:");
      }
     }
     else
     {System.out.println("Record not Found");
     }
    }
    //Login Verify
    public static boolean adminVerify() throws SQLException
    {System.out.println("Enter Your Username");
     //sc.nextLine();
     String u=sc.nextLine();
     System.out.println("Enter Your Current Password");
     String p=sc.nextLine();
     PreparedStatement stmt=con.prepareStatement("Select *from employee where uname=? and upass=? and status=? and utype=?");
     stmt.setString(1, u);
     stmt.setString(2, p);
     stmt.setBoolean(3, true);
     stmt.setString(4,"Admin");
     ResultSet rs=stmt.executeQuery();
     if(rs.next())
     {return true;
     }
     return false;
    }
    public static void adminModule() throws SQLException
    {cls();
     System.out.println("Welcome To Admin Module:");
     System.out.println("Select the operation you want to perform:");
     System.out.println("1-Create Account:");
     System.out.println("2-View All Users:");
     System.out.println("3-View All Prospects:");
     System.out.println("4-Change Password:");
     System.out.println("5-Search Prospect:");
     System.out.println("6-Activate/Deactivate Account:");
     System.out.println("7-Logout:");
     int em=sc.nextInt();
     switch(em)
     {case 1: insertEmpData();
              adminModule();
             break;
      case 2: showEmpData();
              adminModule();
             break;
      case 3: showProspect();
              adminModule();
             break;
      case 4:changePassword();
             adminModule();
             break;
      case 5:searchData();
             adminModule();
             break;
      case 6:statusUpdate();
             adminModule();
             break;
      case 7:System.out.println("Admin Signed Out Sucessfully:");
             break;
      default:System.out.println("Wrong Input:");
     }
    }
    //clear screen
    public static void cls()
    {try{
        new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
    }
    catch(Exception e)
    {}
    }
}
